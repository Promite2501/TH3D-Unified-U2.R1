Please follow the guidelines defined by Atom in their [CONTRIBUTING.md](https://github.com/atom/atom/blob/master/CONTRIBUTING.md).
